from django.apps import AppConfig


class ScientificjournalismConfig(AppConfig):
    name = 'scientificJournalism'
